import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(QuoteBuilderApp());
}

class QuoteBuilderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product Quote Builder',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: QuoteFormPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class LineItem {
  String product;
  int quantity;
  double rate;
  double discount;
  double tax;

  LineItem({
    this.product = '',
    this.quantity = 1,
    this.rate = 0,
    this.discount = 0,
    this.tax = 0,
  });

  double total({bool taxInclusive = true}) {
    double subtotal = (rate - discount) * quantity;
    return taxInclusive ? subtotal : subtotal + subtotal * tax / 100;
  }

  Map<String, dynamic> toJson() => {
    'product': product,
    'quantity': quantity,
    'rate': rate,
    'discount': discount,
    'tax': tax,
  };

  factory LineItem.fromJson(Map<String, dynamic> json) => LineItem(
    product: json['product'],
    quantity: json['quantity'],
    rate: json['rate'],
    discount: json['discount'],
    tax: json['tax'],
  );
}

class Quote {
  String clientName;
  String clientAddress;
  String reference;
  bool taxInclusive;
  String status;
  List<LineItem> items;

  Quote({
    required this.clientName,
    required this.clientAddress,
    required this.reference,
    required this.taxInclusive,
    required this.status,
    required this.items,
  });

  Map<String, dynamic> toJson() => {
    'clientName': clientName,
    'clientAddress': clientAddress,
    'reference': reference,
    'taxInclusive': taxInclusive,
    'status': status,
    'items': items.map((e) => e.toJson()).toList(),
  };

  factory Quote.fromJson(Map<String, dynamic> json) => Quote(
    clientName: json['clientName'],
    clientAddress: json['clientAddress'],
    reference: json['reference'],
    taxInclusive: json['taxInclusive'],
    status: json['status'],
    items: (json['items'] as List).map((e) => LineItem.fromJson(e)).toList(),
  );
}

class QuoteFormPage extends StatefulWidget {
  @override
  _QuoteFormPageState createState() => _QuoteFormPageState();
}

class _QuoteFormPageState extends State<QuoteFormPage> {
  final _clientNameController = TextEditingController();
  final _clientAddressController = TextEditingController();
  final _clientReferenceController = TextEditingController();

  List<LineItem> items = [LineItem()];
  bool taxInclusive = true;
  String quoteStatus = 'Draft';

  final NumberFormat currencyFormat = NumberFormat.currency(symbol: '₹');

  double get subtotal =>
      items.fold(0, (sum, item) => sum + ((item.rate - item.discount) * item.quantity));

  double get grandTotal =>
      items.fold(
          0,
              (sum, item) =>
          sum +
              ((item.rate - item.discount) * item.quantity) *
                  (taxInclusive ? 1 : (1 + item.tax / 100)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('🌟 Product Quote Builder'),
        backgroundColor: Colors.indigo,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: TextButton.icon(
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SavedQuotesPage()),
                );
              },
              icon: Icon(Icons.list_alt, size: 28),
              label: Text('Saved Quotes',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildClientInfoSection(),
            SizedBox(height: 20),
            _buildLineItemsSection(),
            SizedBox(height: 20),
            _buildOptionsSection(),
            SizedBox(height: 20),
            _buildTotalsSection(),
            SizedBox(height: 20),
            _buildQuoteStatusSection(),
            SizedBox(height: 20),
            _buildPreviewSection(),
            SizedBox(height: 20),
            _buildSaveQuoteButton(),
            SizedBox(height: 10),
            _buildSendQuoteButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildClientInfoSection() {
    return Card(
      color: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Client Info',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo)),
            SizedBox(height: 12),
            TextField(
              controller: _clientNameController,
              decoration: InputDecoration(labelText: 'Client Name'),
            ),
            TextField(
              controller: _clientAddressController,
              decoration: InputDecoration(labelText: 'Client Address'),
            ),
            TextField(
              controller: _clientReferenceController,
              decoration: InputDecoration(labelText: 'Reference'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLineItemsSection() {
    return Card(
      color: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Line Items',
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold, color: Colors.indigo)),
            SizedBox(height: 12),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: items.length,
              itemBuilder: (context, index) {
                return _buildLineItemCard(index);
              },
            ),
            SizedBox(height: 12),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo, foregroundColor: Colors.white),
              onPressed: () {
                setState(() {
                  items.add(LineItem());
                });
              },
              icon: Icon(Icons.add),
              label: Text('Add Item'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLineItemCard(int index) {
    final item = items[index];
    return Card(
      color: Colors.grey[50],
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Product/Service'),
                    onChanged: (value) => setState(() => item.product = value),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.redAccent),
                  onPressed: () {
                    setState(() {
                      items.removeAt(index);
                    });
                  },
                )
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Quantity'),
                    keyboardType: TextInputType.number,
                    onChanged: (value) =>
                        setState(() => item.quantity = int.tryParse(value) ?? 1),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Rate'),
                    keyboardType: TextInputType.number,
                    onChanged: (value) =>
                        setState(() => item.rate = double.tryParse(value) ?? 0),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Discount'),
                    keyboardType: TextInputType.number,
                    onChanged: (value) =>
                        setState(() => item.discount = double.tryParse(value) ?? 0),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(labelText: 'Tax %'),
                    keyboardType: TextInputType.number,
                    onChanged: (value) =>
                        setState(() => item.tax = double.tryParse(value) ?? 0),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                'Total: ${currencyFormat.format(item.total(taxInclusive: taxInclusive))}',
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.indigo),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionsSection() {
    return Row(
      children: [
        Expanded(
          child: DropdownButtonFormField<String>(
            value: taxInclusive ? 'Tax Inclusive' : 'Tax Exclusive',
            decoration: InputDecoration(labelText: 'Tax Mode'),
            items: ['Tax Inclusive', 'Tax Exclusive'].map((mode) {
              return DropdownMenuItem(
                value: mode,
                child: Text(mode),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                taxInclusive = value == 'Tax Inclusive';
              });
            },
          ),
        ),
        SizedBox(width: 16),
        Expanded(
          child: DropdownButtonFormField<String>(
            value: quoteStatus,
            decoration: InputDecoration(labelText: 'Quote Status'),
            items: ['Draft', 'Sent', 'Accepted'].map((status) {
              return DropdownMenuItem(
                value: status,
                child: Text(status),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                quoteStatus = value!;
              });
            },
          ),
        ),
      ],
    );
  }

  Widget _buildTotalsSection() {
    return Card(
      color: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Subtotal', style: TextStyle(fontSize: 16)),
                Text('${currencyFormat.format(subtotal)}',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            Divider(color: Colors.grey),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Grand Total',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold, color: Colors.indigo)),
                Text('${currencyFormat.format(grandTotal)}',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold, color: Colors.indigo)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuoteStatusSection() {
    return Text(
      'Quote Status: $quoteStatus',
      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.indigo),
    );
  }

  // ----------------- Updated Preview Section -----------------
  Widget _buildPreviewSection() {
    return Card(
      color: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Quote Preview',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.indigo)),
          SizedBox(height: 8),
          Text('Client: ${_clientNameController.text}'),
          Text('Address: ${_clientAddressController.text}'),
          Text('Reference: ${_clientReferenceController.text}'),
          SizedBox(height: 12),
          Divider(color: Colors.grey),
          // Table header
          Row(
            children: [
              Expanded(flex: 3, child: Text('Product')),
              Expanded(flex: 1, child: Text('Qty', textAlign: TextAlign.center)),
              Expanded(flex: 2, child: Text('Rate', textAlign: TextAlign.center)),
              Expanded(flex: 2, child: Text('Discount', textAlign: TextAlign.center)),
              Expanded(flex: 2, child: Text('Tax %', textAlign: TextAlign.center)),
              Expanded(flex: 2, child: Text('Total', textAlign: TextAlign.right)),
            ],
          ),
          Divider(color: Colors.grey),
          ...items.map((item) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  Expanded(flex: 3, child: Text(item.product)),
                  Expanded(flex: 1, child: Text('${item.quantity}', textAlign: TextAlign.center)),
                  Expanded(flex: 2, child: Text('${currencyFormat.format(item.rate)}', textAlign: TextAlign.center)),
                  Expanded(flex: 2, child: Text('${currencyFormat.format(item.discount)}', textAlign: TextAlign.center)),
                  Expanded(flex: 2, child: Text('${item.tax}%', textAlign: TextAlign.center)),
                  Expanded(flex: 2, child: Text('${currencyFormat.format(item.total(taxInclusive: taxInclusive))}', textAlign: TextAlign.right)),
                ],
              ),
            );
          }).toList(),
          Divider(color: Colors.grey),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Subtotal', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('${currencyFormat.format(subtotal)}', style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Grand Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.indigo)),
              Text('${currencyFormat.format(grandTotal)}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.indigo)),
            ],
          ),
        ]),
      ),
    );
  }

  Widget _buildSaveQuoteButton() {
    return Center(
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green, foregroundColor: Colors.white, padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14)),
        icon: Icon(Icons.save),
        label: Text('Save Quote', style: TextStyle(fontSize: 16)),
        onPressed: () async {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          List<String> savedQuotes = prefs.getStringList('quotes') ?? [];

          Quote quote = Quote(
            clientName: _clientNameController.text,
            clientAddress: _clientAddressController.text,
            reference: _clientReferenceController.text,
            status: quoteStatus,
            taxInclusive: taxInclusive,
            items: items,
          );

          savedQuotes.add(jsonEncode(quote.toJson()));
          await prefs.setStringList('quotes', savedQuotes);

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Quote saved locally! 💾'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 2),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSendQuoteButton() {
    return Center(
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
            backgroundColor: Colors.indigo, foregroundColor: Colors.white, padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14)),
        icon: Icon(Icons.send),
        label: Text('Send Quote', style: TextStyle(fontSize: 16)),
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Quote sent successfully! 🚀'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 2),
            ),
          );
          setState(() {
            quoteStatus = 'Sent';
          });
        },
      ),
    );
  }
}

// -------------------- SAVED QUOTES PAGE --------------------
class SavedQuotesPage extends StatefulWidget {
  @override
  _SavedQuotesPageState createState() => _SavedQuotesPageState();
}

class _SavedQuotesPageState extends State<SavedQuotesPage> {
  List<Quote> savedQuotes = [];

  @override
  void initState() {
    super.initState();
    _loadSavedQuotes();
  }

  Future<void> _loadSavedQuotes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> saved = prefs.getStringList('quotes') ?? [];
    setState(() {
      savedQuotes = saved.map((q) => Quote.fromJson(jsonDecode(q))).toList();
    });
  }

  Future<void> _deleteQuote(int index) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    savedQuotes.removeAt(index);
    List<String> encoded = savedQuotes.map((q) => jsonEncode(q.toJson())).toList();
    await prefs.setStringList('quotes', encoded);
    _loadSavedQuotes();
  }

  final NumberFormat currencyFormat = NumberFormat.currency(symbol: '₹');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Saved Quotes 📄'),
        backgroundColor: Colors.indigo,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: savedQuotes.length,
        itemBuilder: (context, index) {
          final quote = savedQuotes[index];
          double grandTotal =
          quote.items.fold(0, (sum, item) => sum + item.total(taxInclusive: quote.taxInclusive));

          return Card(
            color: Colors.white,
            elevation: 4,
            margin: EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              title: Text(quote.clientName, style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Grand Total: ${currencyFormat.format(grandTotal)}\nStatus: ${quote.status}'),
              isThreeLine: true,
              trailing: IconButton(
                icon: Icon(Icons.delete, color: Colors.redAccent),
                onPressed: () => _deleteQuote(index),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => QuotePreviewPage(quote: quote)),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// -------------------- QUOTE PREVIEW PAGE --------------------
class QuotePreviewPage extends StatelessWidget {
  final Quote quote;
  QuotePreviewPage({required this.quote});

  final NumberFormat currencyFormat = NumberFormat.currency(symbol: '₹');

  double get subtotal =>
      quote.items.fold(0, (sum, item) => sum + ((item.rate - item.discount) * item.quantity));

  double get grandTotal =>
      quote.items.fold(
          0,
              (sum, item) =>
          sum +
              ((item.rate - item.discount) * item.quantity) *
                  (quote.taxInclusive ? 1 : (1 + item.tax / 100)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Quote Preview'), backgroundColor: Colors.indigo),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Card(
          elevation: 6,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Client: ${quote.clientName}', style: TextStyle(fontWeight: FontWeight.bold)),
                Text('Address: ${quote.clientAddress}'),
                Text('Reference: ${quote.reference}'),
                SizedBox(height: 12),
                Divider(color: Colors.grey),
                Row(
                  children: [
                    Expanded(flex: 3, child: Text('Product')),
                    Expanded(flex: 1, child: Text('Qty', textAlign: TextAlign.center)),
                    Expanded(flex: 2, child: Text('Rate', textAlign: TextAlign.center)),
                    Expanded(flex: 2, child: Text('Discount', textAlign: TextAlign.center)),
                    Expanded(flex: 2, child: Text('Tax %', textAlign: TextAlign.center)),
                    Expanded(flex: 2, child: Text('Total', textAlign: TextAlign.right)),
                  ],
                ),
                Divider(color: Colors.grey),
                ...quote.items.map((item) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Row(
                      children: [
                        Expanded(flex: 3, child: Text(item.product)),
                        Expanded(flex: 1, child: Text('${item.quantity}', textAlign: TextAlign.center)),
                        Expanded(flex: 2, child: Text('${currencyFormat.format(item.rate)}', textAlign: TextAlign.center)),
                        Expanded(flex: 2, child: Text('${currencyFormat.format(item.discount)}', textAlign: TextAlign.center)),
                        Expanded(flex: 2, child: Text('${item.tax}%', textAlign: TextAlign.center)),
                        Expanded(flex: 2, child: Text('${currencyFormat.format(item.total(taxInclusive: quote.taxInclusive))}', textAlign: TextAlign.right)),
                      ],
                    ),
                  );
                }).toList(),
                Divider(color: Colors.grey),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Subtotal', style: TextStyle(fontWeight: FontWeight.bold)),
                    Text('${currencyFormat.format(subtotal)}', style: TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Grand Total', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.indigo)),
                    Text('${currencyFormat.format(grandTotal)}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.indigo)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
